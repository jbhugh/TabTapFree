plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.jbhugh.songtabfinder"
    compileSdk = 34  // Downgraded to stable Android 14; 35 is preview

    defaultConfig {
        applicationId = "com.jbhugh.songtabfinder"
        minSdk = 21      // Kept as-is, but consider 24 if possible
        targetSdk = 34   // Matches compileSdk
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }

    buildFeatures {
        compose = false  // Explicitly disable Compose
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")  // Updated to latest
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")  // Kept for networking
    implementation("androidx.activity:activity-ktx:1.9.2")  // Added for Kotlin extensions
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")  // Added for layout flexibility
}